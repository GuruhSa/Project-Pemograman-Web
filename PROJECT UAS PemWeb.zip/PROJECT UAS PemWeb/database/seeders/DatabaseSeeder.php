<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Produk;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'nohp' => '08235237364',
            'password' => Hash::make('1234'),
            'alamat' => 'jl maju jaya',
            'level' => 1
        ]);
        User::create([
            'name' => 'pembeli 1',
            'email' => 'pembeli1@gmail.com',
            'nohp' => '08235217364',
            'password' => Hash::make('password'),
            'alamat' => 'jl jakarta',
            'level' => 0
        ]);
        User::create([
            'name' => 'pembeli 2',
            'email' => 'pembeli2@gmail.com',
            'nohp' => '08235237324',
            'password' => Hash::make('password'),
            'alamat' => 'jl depok',
            'level' => 0
        ]);
        Produk::create([
            'nama_barang' => 'Cat Food',
            'gambar' => 'cat-food.jpg',
            'harga' => 50000
        ]);
        Produk::create([
            'nama_barang' => 'Cat Food ELIT',
            'gambar' => 'Kucing-food.jpg',
            'harga' => 150000
        ]);
        Produk::create([
            'nama_barang' => 'Makanan Anjing Alipo',
            'gambar' => 'dog-food.jpg',
            'harga' => 250000
        ]);
        Produk::create([
            'nama_barang' => 'Makanan Anjing Peddigree',
            'gambar' => 'anjing-food.jpg',
            'harga' => 550000
        ]);
        Produk::create([
            'nama_barang' => 'Bola Mainan Anjing',
            'gambar' => 'bola.jpg',
            'harga' => 10000
        ]);
        Produk::create([
            'nama_barang' => 'Kalung Anjing',
            'gambar' => 'kalung-anjing.jpg',
            'harga' => 50000
        ]);
        Produk::create([
            'nama_barang' => 'Tali Anjing',
            'gambar' => 'tali-anjing.jpg',
            'harga' => 55000
        ]);
        // \App\Models\User::factory(10)->create();
    }
}