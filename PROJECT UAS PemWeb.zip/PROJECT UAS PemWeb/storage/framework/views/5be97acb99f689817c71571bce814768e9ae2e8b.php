<?php $__env->startSection('content'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Data produk</h1>
            <div class="btn-toolbar mb-2 mb-md-0">

            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-info card-outline">
                        <div class="container">
                            <div class="container">
                                <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success text-center" role="alert">
                                        <strong><?php echo e(session('success')); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('danger')): ?>
                                    <div class="alert alert-danger text-center" role="alert">
                                        <strong><?php echo e(session('danger')); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <a href="/dataproduk/create" class="btn btn-success col-2 mt-4">Tambah
                                    produk</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">no</th>
                                        <th scope="col">nama barang</th>
                                        <th scope="col">gambar</th>
                                        <th scope="col">harga</th>
                                        <th scope="col">aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($db->nama_barang); ?></td>
                                            <td>
                                                <img src="<?php echo e('/storage/produk/' . $db->gambar); ?>" alt=""
                                                    class="img-preview img-fluid mb-3 col-sm-5 d-block" width="200"
                                                    height="200">
                                            </td>
                                            <td><?php echo e($db->harga); ?></td>
                                            <td>
                                                <a class="btn btn-warning text-white"
                                                    href="/dataproduk/<?php echo e($db->id); ?>/edit ">edit</a>
                                                <form action="/dataproduk/<?php echo e($db->id); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-danger text-white"
                                                        onclick="return confirm('Anda yakin ingin hapus?')"
                                                        type="submit">hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\e-commers-sederhana-master\resources\views/dashboard/dataproduk.blade.php ENDPATH**/ ?>