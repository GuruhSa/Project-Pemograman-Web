<?php $__env->startSection('body'); ?>
    <!-- content -->
    <div class="container mt-10">
        <div class="col-lg">
            <h1 class="pt-4 text-center">Detail Produk</h1>
            <div class="card mt-10">
                <div class="row">
                    <div class="col-md-4">
                        <img src="<?php echo e('/storage/produk/' . $produkdetail->gambar); ?>" class="img-fluid rounded-start"
                            alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($produkdetail->nama_barang); ?></h5>
                            <p class="card-text">Rp. <?php echo e($produkdetail->harga); ?>,-</p>
                        </div>
                        <div class="row mb-3 mt-10 justify-content-auto">
                            <?php if(auth()->guard('web')->check()): ?>
                                <form action="/inputJumlah/<?php echo e($produkdetail->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-4">
                                        
                                        <input type="number" required name="jumlah" class="form-control"
                                            placeholder="Masukkan jumlah">
                                    </div>
                                    <div class="col-lg-4">
                                        <button type="submit" class="btn btn-success">Masukkan Keranjang</button>
                                        
                                    </div>
                                </form>
                            <?php else: ?>
                                <div class="col-lg-4">
                                    <a href="/register" class="btn btn-success">Masukkan Keranjang</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.beranda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\e-commers-sederhana-master\resources\views/produkdetail.blade.php ENDPATH**/ ?>